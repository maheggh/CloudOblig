# Certificate of excellence
![NTNU-logo](NTNU-logo.png)

Erna Solberg have completed the course IDG2001 Cloud Technologies at the Norwegian University of Science and Technology (NTNU). As part of their course, they have blabla skills, lists, etc.

- PaaS
- SaaS
- IaaS

![Signature](signature.png)

Paul Knutson
Faculty of IE, NTNU